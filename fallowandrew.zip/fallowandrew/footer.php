        <footer class="footer fixed-bottom text-center py-2 theme-bg-dark">
		   
           <p class="copyright"><a href="https://youtube.com/FollowAndrew">FollowAndrew</a> &copy; <?php echo date( 'Y' ); ?> </p>
          
       </footer>
   </div>

   <p>&copy; 2015 RapidTables.com</p>
   
    <?php wp_footer(  );?>
</body>
</html> 
